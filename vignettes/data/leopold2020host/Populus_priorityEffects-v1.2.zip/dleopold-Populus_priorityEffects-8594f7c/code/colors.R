#Color Pallets
pal.treatment <- c("#2F4F4F", "#E69F00", "#56B4E9", "#009E73", "#F0E442")
pal.region <- c("#A2CD5A","#6E8B3D")
pal.genotype <- c("#800000FF", "#767676FF", "#CC8214FF", "#616530FF", "#0F425CFF", "#9A5324FF", "#3E3E23FF",
                  "#D6D6CEFF", "#FFB547FF", "#ADB17DFF", "#5B8FA8FF", "#D49464FF")

